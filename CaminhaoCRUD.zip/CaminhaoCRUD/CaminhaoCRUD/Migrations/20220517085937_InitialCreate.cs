﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CaminhaoCRUD.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
               name: "Caminhao",
               columns: table => new
               {
                   IdCaminhao = table.Column<int>(type: "INTEGER", nullable: false)
                       .Annotation("Sqlite:Autoincrement", true),
                   Modelo = table.Column<string>(type: "TEXT", nullable: false),
                   AnoFabricacao = table.Column<int>(type: "INTEGER", nullable: true),
                   AnoModelo = table.Column<int>(type: "INTEGER", nullable: false),
                   Cor = table.Column<string>(type: "TEXT", nullable: false),
                   QtdeEixos = table.Column<int>(type: "INTEGER", nullable: false)
               },
               constraints: table =>
               {
                   table.PrimaryKey("PK_Caminhao", x => x.IdCaminhao);
               });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
               name: "Caminhao");
        }
    }
}
