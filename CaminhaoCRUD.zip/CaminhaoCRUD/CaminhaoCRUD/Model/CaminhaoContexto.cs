﻿using Microsoft.EntityFrameworkCore;

namespace CaminhaoCRUD.Model
{
    public class CaminhaoContexto : DbContext
    {
        public DbSet<Caminhao> Caminhoes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=Caminhao.db;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Caminhao>().ToTable("Caminhao");
        }
    }
}
