﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CaminhaoCRUD.Model
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
    public class RangeUntilCurrentYearAttribute : RangeAttribute
    {
        public RangeUntilCurrentYearAttribute() : base(Convert.ToInt32(DateTime.Now.Year), DateTime.Now.AddYears(1).Year)
        { }
    }

    public class Caminhao
    {
        [Key]
        public int IdCaminhao { get; set; }
        [Required(ErrorMessage = "Favor informar o Modelo do Caminhão.")]
        [RegularExpression("FM|fm|FH|fh", ErrorMessage = "Favor informe um Modelo de Caminhão! Modelos Permitidos: FH ou FM.")]

        public string Modelo { get; set; }

        public int? AnoFabricacao { get; set; }
        [Required(ErrorMessage = "Favor informar o Ano de Fabricação do Caminhão.")]
        [RangeUntilCurrentYear(ErrorMessage = "O Ano do Modelo deve ser igual ao Ano Atual ou Ano Subsequente.")]

        public int? AnoModelo { get; set; }
        [Required(ErrorMessage = "Favor informar o Ano do Modelo do Caminhão.")]

        public string Cor { get; set; }
        [Required(ErrorMessage = "Favor informar a Cor do Caminhão.")]

        public int? QtdeEixos { get; set; }
        //[Required(ErrorMessage = "Favor informar a Quantidade de Eixos do Caminhão.")]       
    }
}
