using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CaminhaoCRUD.Pages
{
    public class IndexModel : PageModel
    {
        
    }
}

