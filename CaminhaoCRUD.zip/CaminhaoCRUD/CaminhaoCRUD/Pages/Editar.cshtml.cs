using CaminhaoCRUD.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;

namespace CaminhaoCRUD.Pages
{
    public class EditarModel : PageModel
    {
        private readonly CaminhaoContexto _db;

        public EditarModel(CaminhaoContexto db)
        {
            _db = db;
        }
        
        [BindProperty]
        public Caminhao Caminhao { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Caminhao = await _db.Caminhoes.FindAsync(id);

            if (Caminhao == null)            
                return RedirectToPage("/Listar");
            
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)            
                return Page();            
            
            _db.Attach(Caminhao).State = EntityState.Modified;

            Caminhao.Modelo = Caminhao.Modelo.ToUpper();

            try
            {
                await _db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("Ocorreu um erro durante a grava��o - " + ex.Message);
            }

            return RedirectToPage("/Listar");
        }
    }
}
