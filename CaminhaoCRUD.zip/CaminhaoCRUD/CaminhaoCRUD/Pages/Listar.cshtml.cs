using CaminhaoCRUD.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaminhaoCRUD.Pages
{
    public class ListarModel : PageModel
    {
        private readonly CaminhaoContexto _db;

        public ListarModel(CaminhaoContexto db)
        {
            _db = db;
        }

        public IList<Caminhao> Caminhoes { get; private set; }

        public async Task OnGetAsync()
        {
            Caminhoes = await _db.Caminhoes.AsNoTracking().ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var caminhao = await _db.Caminhoes.FindAsync(id);

            if (caminhao != null)
            {
                _db.Caminhoes.Remove(caminhao);
                await _db.SaveChangesAsync();
            }

            return RedirectToPage();
        }
    }
}

