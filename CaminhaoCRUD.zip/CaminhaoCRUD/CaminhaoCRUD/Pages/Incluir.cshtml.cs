using CaminhaoCRUD.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace CaminhaoCRUD.Pages
{
    public class IncluirModel : PageModel
    {
        private readonly CaminhaoContexto _db;

        public IncluirModel(CaminhaoContexto db)
        {
            _db = db;
        }

        [BindProperty]
        public Caminhao Caminhao { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)            
                return Page();            
            
            Caminhao.Modelo = Caminhao.Modelo.ToUpper();

            _db.Caminhoes.Add(Caminhao);
            await _db.SaveChangesAsync();

            return RedirectToPage("/Listar");
        }
    }
}
